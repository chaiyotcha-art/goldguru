
Welcome Page (static)
---------------------
Files:
- index.html
- styles.css
- images/   (contains the photos you provided)

How to use:
1. Unzip the archive.
2. Open index.html in a browser to preview locally.
3. To deploy:
   - GitHub Pages: create a new repository, push files to the repo, enable Pages from branch 'main' (or use /docs).
   - Netlify: drag & drop the unzipped folder to Netlify Drop.
   - Vercel: use 'vercel' or import the repo.

Edit:
- Update contact details in index.html (section id="contact").
